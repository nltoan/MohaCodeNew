GÓI ỨNG VIÊN PORTAL VÀ DUBLIN CORE - 06/11/2026
94/95 URL được tạo snapshot; 45 snapshot thiếu ngày nguồn. Xem snapshot-manifest.json.
Chưa kiểm thử IIS staging hoặc triển khai production. Không thay Web.config hiện có. Gộp quy tắc trong dublin-core-rewrite.fragment.xml theo DUBLIN-CORE-STATIC.md; thử root, các trang có/không có snapshot, bot, media, 404, SPA và rollback.
Dữ liệu snapshot là ảnh chụp tại thời điểm tạo; cần cập nhật khi nội dung thay đổi. Xác nhận ngày trang chủ và bổ sung ngày hợp lệ cho các nội dung thiếu. Không coi gói này là chứng nhận đáp ứng toàn bộ công văn.
Triển khai trên bản sao staging trước. Sao lưu assets, index, runtime-config và cấu hình IIS. Giữ các assets cũ; cập nhật assets trước index cuối, purge cache sau kiểm thử.
