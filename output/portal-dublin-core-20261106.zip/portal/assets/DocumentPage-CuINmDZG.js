import{j as e,C as s,O as t}from"./index-CIyDnToi.js";const r=()=>e.jsx("div",{className:"mh-document",children:e.jsx(s,{children:e.jsx(t,{})})});export{r as DocumentPage};
